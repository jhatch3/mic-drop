// ds.jsx — MIC DROP early-2000s design system
// Shared retro-web building blocks: palette, logo, ticker marquee, beveled
// buttons, GO! pills, splat blobs, colored panels, striped image placeholders,
// plus the BROADCAST kit (on-air bar, lower-third, score bug, nameplate, MC
// voice waveform). All exported to window for the screen files.

const PAL = {
  ink:       '#0B0B0B',
  slime:     '#B6FF00',
  slimeDk:   '#79B000',
  orange:    '#FF6B00',
  orangeDk:  '#B84A00',
  purple:    '#8E2DE2',
  purpleDp:  '#5A1799',
  magenta:   '#FF1C8E',
  cyan:      '#13D7E8',
  cyanDk:    '#0792A0',
  yellow:    '#FFD400',
  red:       '#FF2E2E',
  cream:     '#FFFDEB',
  paper:     '#F2ECD6',
  white:     '#FFFFFF',
};

const FONT = {
  display: "'Anton', 'Arial Narrow', sans-serif",
  logo:    "'Bungee', 'Anton', sans-serif",
  body:    "'Archivo', system-ui, sans-serif",
  mono:    "'VT323', 'Courier New', monospace",
};

// Hard offset shadow + thick ink outline — the workhorse panel look.
function bevelPanel(bg, { outline = PAL.ink, shadow = 6, bw = 3 } = {}) {
  return {
    background: bg,
    border: `${bw}px solid ${outline}`,
    boxShadow: `${shadow}px ${shadow}px 0 ${PAL.ink}`,
    borderRadius: 0,
  };
}

// Chunky 3D beveled button face.
function bevelFace(bg) {
  return {
    background: bg,
    border: `3px solid ${PAL.ink}`,
    boxShadow:
      `inset 3px 3px 0 rgba(255,255,255,0.5), inset -3px -3px 0 rgba(0,0,0,0.28), 4px 4px 0 ${PAL.ink}`,
    borderRadius: 0,
  };
}

// ── Chevron run ">>" ─────────────────────────────────────────────
function Chevrons({ color = PAL.ink, size = 16, n = 2, style = {} }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', ...style }}>
      {Array.from({ length: n }).map((_, i) => (
        <span key={i} style={{
          fontFamily: FONT.display, color, fontSize: size, lineHeight: 1,
          marginLeft: i ? -size * 0.28 : 0,
        }}>»</span>
      ))}
    </span>
  );
}

// ── Splat blob (basic irregular ellipse) ─────────────────────────
function Splat({ color = PAL.orange, size = 120, children, style = {}, spin = false, outline = PAL.ink }) {
  return (
    <div style={{
      width: size, height: size, background: color,
      border: `3px solid ${outline}`,
      borderRadius: '49% 51% 47% 53% / 53% 47% 53% 47%',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      textAlign: 'center', flexShrink: 0,
      animation: spin ? 'mdSpin 14s linear infinite' : 'none',
      ...style,
    }}>{children}</div>
  );
}

// ── Beveled action button ────────────────────────────────────────
function BevelBtn({ color = PAL.orange, fg = PAL.ink, children, big = false, blink = false, style = {} }) {
  return (
    <span className={blink ? 'md-blink' : 'md-press'} style={{
      ...bevelFace(color),
      color: fg,
      fontFamily: FONT.display,
      fontSize: big ? 26 : 18,
      letterSpacing: 0.5,
      textTransform: 'uppercase',
      padding: big ? '12px 28px' : '8px 18px',
      display: 'inline-flex', alignItems: 'center', gap: 8,
      cursor: 'pointer', userSelect: 'none', whiteSpace: 'nowrap',
      ...style,
    }}>{children}</span>
  );
}

// ── Black "GO!" pill (period CTA) ────────────────────────────────
function GoPill({ label = 'GO!', color = PAL.slime, style = {} }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      background: PAL.ink, color,
      fontFamily: FONT.display, fontSize: 16, letterSpacing: 1,
      padding: '5px 14px', borderRadius: 999,
      border: `2px solid ${PAL.ink}`, whiteSpace: 'nowrap', ...style,
    }}>
      {label}<Chevrons color={color} size={13} />
    </span>
  );
}

// ── Colored panel with title strip ───────────────────────────────
function Panel({ color = PAL.cream, title, titleColor = PAL.ink, titleBg = PAL.ink, titleFg = PAL.slime,
                 children, shadow = 6, style = {}, bodyStyle = {} }) {
  return (
    <div style={{ ...bevelPanel(color, { shadow }), ...style }}>
      {title && (
        <div style={{
          background: titleBg, color: titleFg, fontFamily: FONT.display,
          fontSize: 17, letterSpacing: 0.6, textTransform: 'uppercase',
          padding: '6px 12px', borderBottom: `3px solid ${PAL.ink}`,
          display: 'flex', alignItems: 'center', gap: 8,
        }}>{title}</div>
      )}
      <div style={{ padding: 14, ...bodyStyle }}>{children}</div>
    </div>
  );
}

// ── Marquee ticker bar ───────────────────────────────────────────
function Ticker({ items = [], bg = PAL.slime, fg = PAL.ink, label = 'MIC TICKER', speed = 26 }) {
  const row = items.join('   \u00A0\u25C6\u00A0   ');
  return (
    <div style={{
      display: 'flex', alignItems: 'stretch', background: bg,
      borderTop: `3px solid ${PAL.ink}`, borderBottom: `3px solid ${PAL.ink}`,
      height: 34, overflow: 'hidden',
    }}>
      <div style={{
        background: PAL.ink, color: bg, fontFamily: FONT.display, fontSize: 15,
        letterSpacing: 1, display: 'flex', alignItems: 'center', padding: '0 12px',
        whiteSpace: 'nowrap', flexShrink: 0,
      }}>
        {label}<Chevrons color={bg} size={14} n={3} style={{ marginLeft: 6 }} />
      </div>
      <div style={{ overflow: 'hidden', flex: 1, display: 'flex', alignItems: 'center' }}>
        <div style={{
          fontFamily: FONT.mono, fontSize: 20, color: fg, whiteSpace: 'nowrap',
          animation: `mdMarquee ${speed}s linear infinite`, paddingLeft: '100%',
        }}>{row}{'   \u00A0\u25C6\u00A0   '}{row}</div>
      </div>
    </div>
  );
}

// ── Broadcast: stage background (radial wash + spotlight stripes) ─
function StageBG({ children, style = {} }) {
  return (
    <div style={{ position: 'relative', flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column',
      background: `radial-gradient(circle at 50% 24%, ${PAL.purple} 0%, ${PAL.purpleDp} 72%)`, ...style }}>
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none',
        background: `repeating-linear-gradient(90deg, transparent 0 74px, rgba(255,255,255,0.05) 74px 76px)` }} />
      {children}
    </div>
  );
}

// ── Broadcast: ON-AIR top bar ────────────────────────────────────
function OnAirBar({ right = 'MIC DROP TV \u00B7 LIVE FROM DEVNET', tag = 'ON AIR', tagColor = PAL.red, blink = true }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '9px 16px',
      borderBottom: `4px solid ${PAL.ink}`, background: PAL.ink, flexShrink: 0 }}>
      <span className={blink ? 'md-blink' : ''} style={{ background: tagColor, color: PAL.white,
        fontFamily: FONT.display, fontSize: 15, padding: '3px 12px', letterSpacing: 1 }}>{'\u25CF'} {tag}</span>
      <Logo scale={0.58} />
      <span style={{ marginLeft: 'auto', fontFamily: FONT.mono, fontSize: 18, color: PAL.slime }}>{right}</span>
    </div>
  );
}

// ── Broadcast: lower-third banner (the signature element) ────────
function LowerThird({ kicker = 'LIVE', kickerColor = PAL.magenta, kickerFg = PAL.white,
                      headline, bodyColor = PAL.slime, action }) {
  return (
    <div style={{ display: 'flex', alignItems: 'stretch', borderTop: `4px solid ${PAL.ink}`, flexShrink: 0 }}>
      <div style={{ background: kickerColor, color: kickerFg, fontFamily: FONT.display, fontSize: 20,
        letterSpacing: 1, padding: '14px 18px', display: 'flex', alignItems: 'center',
        borderRight: `4px solid ${PAL.ink}`, whiteSpace: 'nowrap' }}>{kicker}</div>
      <div style={{ background: bodyColor, color: PAL.ink, fontFamily: FONT.body, fontWeight: 800, fontSize: 21,
        padding: '12px 18px', display: 'flex', alignItems: 'center', flex: 1, lineHeight: 1.12 }}>{headline}</div>
      {action && <div style={{ display: 'flex', alignItems: 'center', padding: '0 14px', background: bodyColor,
        borderLeft: `4px solid ${PAL.ink}` }}>{action}</div>}
    </div>
  );
}

// ── Broadcast: VS score bug ──────────────────────────────────────
function ScoreBug({ a, b, big = false }) {
  const fs = big ? 34 : 26;
  const seg = (s, lead) => (
    <span style={{ background: s.color, color: s.fg || PAL.ink, fontFamily: FONT.display, fontSize: fs,
      padding: big ? '10px 20px' : '8px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
      {lead ? <>{s.name}<b>{s.score}</b></> : <><b>{s.score}</b>{s.name}</>}
    </span>
  );
  return (
    <div style={{ display: 'inline-flex', alignItems: 'stretch', border: `4px solid ${PAL.ink}`,
      boxShadow: `6px 6px 0 ${PAL.ink}` }}>
      {seg(a, true)}
      <span style={{ background: PAL.ink, color: PAL.white, fontFamily: FONT.display, fontSize: fs * 0.72,
        padding: '0 12px', display: 'flex', alignItems: 'center' }}>VS</span>
      {seg(b, false)}
    </div>
  );
}

// ── Broadcast: competitor nameplate ──────────────────────────────
function Nameplate({ name, sub, color = PAL.slime, kicker = 'NOW SINGING' }) {
  return (
    <div style={{ border: `4px solid ${PAL.ink}`, boxShadow: `5px 5px 0 ${PAL.ink}`, display: 'inline-block' }}>
      <div style={{ background: PAL.ink, color, fontFamily: FONT.display, fontSize: 14, letterSpacing: 2,
        padding: '4px 14px' }}>{kicker}</div>
      <div style={{ background: color, color: PAL.ink, fontFamily: FONT.display, fontSize: 32, letterSpacing: 0.5,
        padding: '6px 16px', display: 'flex', alignItems: 'baseline', gap: 10 }}>
        {name}{sub && <span style={{ fontFamily: FONT.mono, fontSize: 16 }}>{sub}</span>}
      </div>
    </div>
  );
}

// ── Broadcast: the MC's voice — a commentary waveform (no mascot) ─
function MCWave({ quote, label = 'THE MC \u00B7 ON THE CALL', bars = 30, color = PAL.slime, compact = false }) {
  const hs = Array.from({ length: bars }).map((_, i) =>
    16 + Math.abs(Math.sin(i * 0.9) * 0.6 + Math.sin(i * 0.37) * 0.4) * (compact ? 26 : 44));
  return (
    <div style={{ ...bevelPanel(PAL.white), padding: compact ? 12 : 16 }}>
      <div style={{ marginBottom: 8 }}>
        <span style={{ background: PAL.magenta, color: PAL.white, fontFamily: FONT.display, fontSize: 14,
          letterSpacing: 1, padding: '4px 12px' }}>{'\uD83D\uDD0A'} {label}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 3, height: compact ? 40 : 60, marginBottom: quote ? 10 : 0 }}>
        {hs.map((h, i) => (
          <div key={i} className="md-eq" style={{ flex: 1, height: h,
            background: i % 3 === 0 ? PAL.magenta : color, border: `1.5px solid ${PAL.ink}`,
            animationDelay: `${(i % 7) * 0.11}s` }} />
        ))}
      </div>
      {quote && <div style={{ fontFamily: FONT.body, fontWeight: 800, fontSize: compact ? 17 : 21,
        lineHeight: 1.18 }}>{quote}</div>}
    </div>
  );
}

// ── MIC DROP logo lockup ─────────────────────────────────────────
function Logo({ scale = 1, mono = false }) {
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 10 * scale }}>
      <div style={{ position: 'relative', transform: 'rotate(-8deg)' }}>
        <span style={{
          fontFamily: FONT.logo, fontSize: 34 * scale, lineHeight: 0.9,
          color: PAL.white, WebkitTextStroke: `${2.5 * scale}px ${PAL.ink}`,
          textShadow: `${3 * scale}px ${3 * scale}px 0 ${PAL.ink}`,
          letterSpacing: 0.5,
        }}>MIC</span>
      </div>
      <div style={{
        fontFamily: FONT.logo, fontSize: 34 * scale, lineHeight: 0.9,
        color: PAL.yellow, WebkitTextStroke: `${2.5 * scale}px ${PAL.ink}`,
        textShadow: `${3 * scale}px ${3 * scale}px 0 ${PAL.ink}`,
        background: PAL.purple, padding: `${4 * scale}px ${10 * scale}px`,
        border: `${3 * scale}px solid ${PAL.ink}`, transform: 'rotate(2deg)',
      }}>DROP</div>
    </div>
  );
}

// ── Tab navigation (chunky multi-color rounded-top tabs) ─────────
const NAV_TABS = [
  { label: 'LOBBY',  color: PAL.red },
  { label: 'BATTLE', color: PAL.orange },
  { label: 'SONGS',  color: PAL.yellow },
  { label: 'STAKES', color: PAL.slime },
  { label: 'RANKS',  color: PAL.cyan },
  { label: 'THE MC', color: PAL.magenta },
  { label: 'WALLET', color: PAL.purple },
];
function TabNav({ active = 'LOBBY' }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 4, padding: 0 }}>
      {NAV_TABS.map((t) => {
        const on = t.label === active;
        return (
          <div key={t.label} style={{
            fontFamily: FONT.display, fontSize: 15, letterSpacing: 0.5,
            color: PAL.ink, background: t.color,
            padding: on ? '12px 14px 14px' : '8px 14px 10px',
            border: `3px solid ${PAL.ink}`, borderBottom: 'none',
            borderRadius: '12px 12px 0 0',
            marginBottom: on ? -3 : 0, position: 'relative', zIndex: on ? 3 : 1,
            boxShadow: on ? 'none' : 'inset 0 -6px 0 rgba(0,0,0,0.16)',
            cursor: 'pointer', whiteSpace: 'nowrap',
          }}>{t.label}</div>
        );
      })}
    </div>
  );
}

// ── Striped image placeholder ────────────────────────────────────
function ImgSlot({ label = 'IMAGE', w = '100%', h = 120, color = PAL.cyan, style = {} }) {
  return (
    <div style={{
      width: w, height: h,
      background: `repeating-linear-gradient(45deg, ${color}22 0 10px, ${color}44 10px 20px)`,
      border: `3px dashed ${PAL.ink}`, display: 'flex', alignItems: 'center',
      justifyContent: 'center', ...style,
    }}>
      <span style={{ fontFamily: FONT.mono, fontSize: 16, color: PAL.ink, letterSpacing: 1,
        background: PAL.cream, padding: '2px 8px', border: `2px solid ${PAL.ink}` }}>{label}</span>
    </div>
  );
}

// ── Login / wallet strip (the lime "Enter myNick"-style bar) ─────
function LoginStrip({ note = "No NickName? Connect a wallet & jump in!", cta = 'CONNECT WALLET' }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12, background: PAL.slime,
      borderBottom: `4px solid ${PAL.ink}`, padding: '6px 14px',
    }}>
      <Chevrons size={22} n={2} />
      <span style={{
        background: PAL.ink, color: PAL.slime, fontFamily: FONT.display, fontSize: 15,
        padding: '5px 16px', borderRadius: 999, letterSpacing: 0.5,
      }}>LOG IN</span>
      <span style={{ fontFamily: FONT.mono, fontSize: 19, color: PAL.purpleDp, flex: 1 }}>{note}</span>
      <BevelBtn color={PAL.orange} style={{ fontSize: 15, padding: '6px 14px' }}>{cta}</BevelBtn>
    </div>
  );
}

// ── Full site chrome wrapper for host (laptop) screens ───────────
function SiteChrome({ active = 'LOBBY', ticker, children, width = 1024, height }) {
  return (
    <div style={{
      width, minHeight: height, height, background: PAL.paper, fontFamily: FONT.body,
      color: PAL.ink, display: 'flex', flexDirection: 'column', overflow: 'hidden',
    }}>
      {/* top brand + tabs band */}
      <div style={{ background: PAL.white, borderBottom: `4px solid ${PAL.ink}`, padding: '12px 18px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <Logo scale={1} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontFamily: FONT.mono, fontSize: 18, color: PAL.purpleDp }}>devnet · 0.42 SOL</span>
            <BevelBtn color={PAL.purple} fg={PAL.white} style={{ fontSize: 15, padding: '6px 14px' }}>★ MY WALLET</BevelBtn>
          </div>
        </div>
        <TabNav active={active} />
      </div>
      <LoginStrip />
      <Ticker items={ticker || [
        'PITCH BATTLE IS LIVE', 'WINNER TAKES THE POT', 'THE MC IS WARMING UP HIS BURNS',
        'STAKE \u00B7 SING \u00B7 SLAY', 'DON\u2019T CHOKE ON THE HIGH NOTE',
      ]} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>{children}</div>
    </div>
  );
}

Object.assign(window, {
  PAL, FONT, bevelPanel, bevelFace,
  Chevrons, Splat, BevelBtn, GoPill, Panel, Ticker, Logo,
  TabNav, ImgSlot, LoginStrip, SiteChrome, NAV_TABS,
  StageBG, OnAirBar, LowerThird, ScoreBug, Nameplate, MCWave,
});
