// broadcast.jsx — MIC DROP "Broadcast" art direction.
// On-air framing: ON-AIR bar on top, purple stage in the middle, signature
// lower-third banner on the bottom. No mascot — the MC is a voice (MCWave) and
// a lower-third caption. Host (laptop 1024×720) + Phone second-screen (390×760).

const BW = 1024, BH = 720;

// shells ----------------------------------------------------------------------
function BC({ children }) {
  return (
    <div style={{ width: BW, height: BH, background: PAL.purpleDp, fontFamily: FONT.body, color: PAL.white,
      display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>{children}</div>
  );
}
function SongLine({ title, artist, diff, active }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '7px 12px',
      background: active ? PAL.yellow : PAL.cream, borderBottom: `2px solid ${PAL.ink}`, color: PAL.ink }}>
      <span style={{ fontFamily: FONT.display, fontSize: 15 }}>{active ? '\u25B6' : '\u266A'}</span>
      <span style={{ fontFamily: FONT.display, fontSize: 16, flex: 1, letterSpacing: 0.3 }}>{title}</span>
      <span style={{ fontFamily: FONT.mono, fontSize: 15, color: PAL.purpleDp }}>{artist}</span>
      <span style={{ fontFamily: FONT.mono, fontSize: 14 }}>{'\u2605'.repeat(diff)}<span style={{ opacity: 0.3 }}>{'\u2605'.repeat(5 - diff)}</span></span>
    </div>
  );
}
function StageCard({ title, titleBg = PAL.ink, titleFg = PAL.slime, children, w, style = {} }) {
  return (
    <div style={{ ...bevelPanel(PAL.white, { shadow: 7 }), width: w, color: PAL.ink, zIndex: 2, ...style }}>
      {title && <div style={{ background: titleBg, color: titleFg, fontFamily: FONT.display, fontSize: 16,
        letterSpacing: 1, padding: '6px 14px', borderBottom: `3px solid ${PAL.ink}` }}>{title}</div>}
      <div style={{ padding: 16 }}>{children}</div>
    </div>
  );
}

// broadcast pitch meter -------------------------------------------------------
function PitchMeter({ w = 760, h = 230 }) {
  const path = (seed, amp) => {
    let d = '';
    for (let i = 0; i <= 44; i++) {
      const x = (i / 44) * w;
      const y = h / 2 + Math.sin(i * 0.5 + seed) * amp + Math.sin(i * 0.21 + seed) * (amp * 0.55);
      d += `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)} `;
    }
    return d;
  };
  const cx = w * 0.66, cy = h / 2 + Math.sin(0.66 * 22 + 0.8) * 38;
  return (
    <div style={{ border: `4px solid ${PAL.ink}`, boxShadow: `6px 6px 0 ${PAL.ink}`, position: 'relative' }}>
      <svg width="100%" viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
        <rect x="0" y="0" width={w} height={h} fill={PAL.ink} />
        {Array.from({ length: 7 }).map((_, i) => (
          <line key={i} x1="0" x2={w} y1={(i + 1) * h / 8} y2={(i + 1) * h / 8} stroke="#ffffff18" strokeWidth="1" />
        ))}
        <path d={path(0, 42)} fill="none" stroke={PAL.magenta} strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" />
        <path d={path(0.8, 38)} fill="none" stroke={PAL.yellow} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx={cx} cy={cy} r="9" fill={PAL.slime} stroke={PAL.ink} strokeWidth="3" />
      </svg>
      <div style={{ position: 'absolute', top: 8, left: 10, display: 'flex', gap: 8 }}>
        {[['TARGET', PAL.magenta], ['YOU', PAL.yellow]].map(([l, c]) => (
          <span key={l} style={{ fontFamily: FONT.display, fontSize: 13, color: PAL.ink, background: c,
            padding: '2px 8px', border: `2px solid ${PAL.ink}` }}>{'\u25CF'} {l}</span>
        ))}
      </div>
    </div>
  );
}

// ── 1 · PRE-SHOW / CREATE BATTLE ─────────────────────────────────
function BcLobby() {
  return (
    <BC>
      <OnAirBar tag="STANDBY" tagColor={PAL.cyan} blink={false} right="MIC DROP TV · GREEN ROOM" />
      <StageBG>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center',
          justifyContent: 'center', gap: 20, padding: '20px 24px', zIndex: 2 }}>
          <div style={{ fontFamily: FONT.display, fontSize: 26, letterSpacing: 4, color: PAL.yellow }}>TONIGHT'S MATCHUP</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 22 }}>
            <Nameplate kicker="CHAMPION" name="KAZOO_KING" sub="15-3" color={PAL.slime} />
            <div style={{ fontFamily: FONT.display, fontSize: 46, color: PAL.white, WebkitTextStroke: `2px ${PAL.ink}` }}>VS</div>
            <Nameplate kicker="CHALLENGER" name="OPEN SEAT" sub="?-?" color={PAL.magenta} />
          </div>
          <StageCard title="SET THE BILL" w={560}>
            <div style={{ fontFamily: FONT.display, fontSize: 13, letterSpacing: 1, color: PAL.purpleDp, marginBottom: 5 }}>TRACK</div>
            <div style={{ border: `3px solid ${PAL.ink}`, marginBottom: 14 }}>
              <SongLine title="FIREWORK" artist="Katy Perry" diff={3} active />
              <SongLine title="SINCE U BEEN GONE" artist="Kelly Clarkson" diff={4} />
            </div>
            <div style={{ display: 'flex', gap: 14 }}>
              {[['WAGER', '0.01 SOL', PAL.purpleDp], ['WINNER TAKES', '0.0198 SOL', PAL.slimeDk]].map(([l, v, c]) => (
                <div key={l} style={{ flex: 1 }}>
                  <div style={{ fontFamily: FONT.display, fontSize: 13, letterSpacing: 1, color: PAL.purpleDp, marginBottom: 5 }}>{l}</div>
                  <div style={{ ...bevelPanel(PAL.cream, { shadow: 0 }), padding: '8px 12px', fontFamily: FONT.display,
                    fontSize: 26, color: c }}>{v}</div>
                </div>
              ))}
            </div>
          </StageCard>
        </div>
      </StageBG>
      <LowerThird kicker="UP NEXT" kickerColor={PAL.yellow} kickerFg={PAL.ink}
        headline="Lock the track and the wager — then put it on air."
        action={<BevelBtn color={PAL.slime}>GO LIVE »</BevelBtn>} />
    </BC>
  );
}

// ── 2 · GREEN ROOM / WAITING (call-in) ───────────────────────────
function QRBlock({ size = 142 }) {
  const n = 13, cell = size / n, cells = [];
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
    const finder = (x < 4 && y < 4) || (x > n - 5 && y < 4) || (x < 4 && y > n - 5);
    const on = finder ? !((x === 1 || x === n - 2 || x === 0 || x === n - 1) ^ (y === 1 || y === n - 2 || y === 0 || y === n - 1))
                       : ((x * 7 + y * 13 + x * y) % 3 === 0);
    if (on) cells.push(<rect key={`${x}-${y}`} x={x * cell} y={y * cell} width={cell} height={cell} fill={PAL.ink} />);
  }
  return <div style={{ background: PAL.white, border: `4px solid ${PAL.ink}`, padding: 7, lineHeight: 0 }}><svg width={size} height={size}>{cells}</svg></div>;
}
function BcWaiting() {
  return (
    <BC>
      <OnAirBar tag="STANDBY" tagColor={PAL.cyan} blink={false} right="MIC DROP TV · CALL-IN" />
      <StageBG>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center',
          justifyContent: 'center', gap: 18, padding: '18px 24px', zIndex: 2 }}>
          <div style={{ fontFamily: FONT.display, fontSize: 30, letterSpacing: 2, color: PAL.yellow,
            textShadow: `3px 3px 0 ${PAL.ink}` }}>CALL IN TO COMPETE</div>
          <div style={{ display: 'flex', gap: 22, alignItems: 'stretch' }}>
            <StageCard title="ROOM CODE" titleBg={PAL.purple} titleFg={PAL.white} style={{ textAlign: 'center' }}>
              <div style={{ fontFamily: FONT.display, fontSize: 84, letterSpacing: 8, color: PAL.purpleDp, lineHeight: 0.9 }}>PB4K9</div>
              <div style={{ fontFamily: FONT.mono, fontSize: 17, color: PAL.purpleDp }}>micdrop.fun/play</div>
            </StageCard>
            <StageCard title="OR SCAN" titleBg={PAL.cyanDk} titleFg={PAL.white}>
              <QRBlock size={142} />
            </StageCard>
          </div>
          <StageCard title={<>ROSTER <span style={{ color: PAL.slime, marginLeft: 6 }}>1 / 2 CHECKED IN</span></>} w={540}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontFamily: FONT.mono, fontSize: 17,
              padding: '7px 10px', background: PAL.slime, border: `2px solid ${PAL.ink}`, marginBottom: 8, whiteSpace: 'nowrap' }}>
              <span style={{ fontFamily: FONT.display, color: PAL.slimeDk }}>{'\u2713'}</span>
              <b style={{ fontFamily: FONT.body }}>kazoo_king</b>
              <span style={{ color: PAL.purpleDp }}>7Bx9…f3Q</span>
              <span style={{ marginLeft: 'auto', fontFamily: FONT.display }}>P1 · HOST</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontFamily: FONT.mono, fontSize: 17,
              padding: '7px 10px', border: `2px dashed ${PAL.ink}`, color: PAL.purpleDp, whiteSpace: 'nowrap' }}>
              <span className="md-blink" style={{ fontFamily: FONT.display, color: PAL.orange }}>{'\u25CF'}</span>
              standing by for challenger…
            </div>
          </StageCard>
        </div>
      </StageBG>
      <LowerThird kicker="WAITING" kickerColor={PAL.orange} kickerFg={PAL.white}
        headline="Challenger hasn't checked in yet. We'll stall — the MC's got material."
        action={<span style={{ opacity: 0.45 }}><BevelBtn color={PAL.slime}>START »</BevelBtn></span>} />
    </BC>
  );
}

// ── 3 · ON AIR / SINGING ─────────────────────────────────────────
function BcSinging() {
  return (
    <BC>
      <OnAirBar tag="ON AIR" tagColor={PAL.red} right="ROUND 1 · LIVE · 02:14" />
      <StageBG>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: 18, gap: 14, zIndex: 2 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <Nameplate kicker="NOW SINGING" name="KAZOO_KING" color={PAL.slime} />
            <ScoreBug a={{ name: 'KAZOO', score: 87, color: PAL.slime }} b={{ name: 'PETE', score: '—', color: PAL.magenta, fg: PAL.white }} />
          </div>
          <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 250px', gap: 14, alignItems: 'center' }}>
            <PitchMeter />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div style={{ ...bevelPanel(PAL.slime), padding: '10px 14px', textAlign: 'center', color: PAL.ink }}>
                <div style={{ fontFamily: FONT.display, fontSize: 13, letterSpacing: 2 }}>LIVE SCORE</div>
                <div style={{ fontFamily: FONT.display, fontSize: 64, lineHeight: 0.9, textShadow: `3px 3px 0 ${PAL.white}` }}>87</div>
                <div style={{ fontFamily: FONT.mono, fontSize: 15 }}>312 / 358 hit</div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                {[['YOU', 'A4', PAL.yellow], ['TGT', 'A#4', PAL.magenta]].map(([l, note, c]) => (
                  <div key={l} style={{ ...bevelPanel(PAL.white, { shadow: 0 }), padding: '6px', textAlign: 'center', color: PAL.ink }}>
                    <div style={{ fontFamily: FONT.display, fontSize: 11, letterSpacing: 1, color: PAL.purpleDp }}>{l}</div>
                    <div style={{ fontFamily: FONT.mono, fontSize: 28, color: c, WebkitTextStroke: `1px ${PAL.ink}` }}>{note}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </StageBG>
      <LowerThird kicker={'\u266A LIVE'} kickerColor={PAL.red} kickerFg={PAL.white}
        headline={<span>'Cause baby you're a <span style={{ background: PAL.yellow, padding: '0 6px', border: `2px solid ${PAL.ink}` }}>FIREWORK</span></span>}
        action={<BevelBtn color={PAL.orange} fg={PAL.white}>END TURN »</BevelBtn>} />
    </BC>
  );
}

// ── 4 · INSTANT REPLAY / SCORING ─────────────────────────────────
function BcScoring() {
  return (
    <BC>
      <OnAirBar tag="REPLAY" tagColor={PAL.yellow} blink={false} right="MIC DROP TV · JUDGES' ROOM" />
      <StageBG>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center',
          justifyContent: 'center', gap: 18, padding: '20px 24px', zIndex: 2 }}>
          <div style={{ fontFamily: FONT.display, fontSize: 56, letterSpacing: 2, color: PAL.white,
            textShadow: `4px 4px 0 ${PAL.ink}` }}>INSTANT REPLAY<span className="md-blink">…</span></div>
          <ScoreBug big a={{ name: 'KAZOO', score: 87, color: PAL.slime }} b={{ name: 'PETE', score: 71, color: PAL.magenta, fg: PAL.white }} />
          <div style={{ width: 620 }}>
            <MCWave label="THE MC · DELIBERATING" quote="Both takes are in. Let me find the words for what Pete just did to that chorus…" />
          </div>
          <div style={{ width: 480, height: 22, background: PAL.ink, border: `3px solid ${PAL.ink}`, boxShadow: `4px 4px 0 ${PAL.ink}` }}>
            <div style={{ width: '70%', height: '100%', background: `repeating-linear-gradient(45deg, ${PAL.orange} 0 12px, ${PAL.yellow} 12px 24px)` }} />
          </div>
        </div>
      </StageBG>
      <LowerThird kicker="SCORING" kickerColor={PAL.magenta}
        headline="Reviewing every frame of both performances. Counting the SOL. Sharpening the burns." />
    </BC>
  );
}

// ── 5 · RESULTS / FINAL ──────────────────────────────────────────
function BcResults() {
  return (
    <BC>
      <OnAirBar tag="FINAL" tagColor={PAL.slime} blink={false} right="MIC DROP TV · THE VERDICT" />
      <StageBG>
        <div style={{ flex: 1, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 2 }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontFamily: FONT.display, fontSize: 26, letterSpacing: 4, color: PAL.yellow }}>YOUR WINNER</div>
            <div style={{ fontFamily: FONT.display, fontSize: 92, lineHeight: 0.9, color: PAL.white,
              textShadow: `5px 5px 0 ${PAL.ink}`, transform: 'rotate(-1deg)' }}>KAZOO_KING</div>
            <div style={{ marginTop: 16 }}>
              <ScoreBug big a={{ name: 'KAZOO', score: 87, color: PAL.slime }} b={{ name: 'PETE', score: 71, color: PAL.magenta, fg: PAL.white }} />
            </div>
          </div>
          {/* payout bug */}
          <div style={{ position: 'absolute', left: 26, top: 22 }}>
            <Splat color={PAL.yellow} size={120} style={{ transform: 'rotate(-8deg)' }}>
              <span style={{ fontFamily: FONT.display, fontSize: 17, lineHeight: 1, color: PAL.ink }}>
                +0.0198<br/>SOL<br/><span style={{ fontSize: 11 }}>PAID {'\u2713'}</span></span>
            </Splat>
          </div>
          {/* winner cam */}
          <div style={{ position: 'absolute', right: 24, bottom: 18, transform: 'rotate(2deg)' }}>
            <div style={{ border: `4px solid ${PAL.ink}`, boxShadow: `5px 5px 0 ${PAL.ink}` }}>
              <div style={{ background: PAL.ink, color: PAL.slime, fontFamily: FONT.display, fontSize: 13,
                letterSpacing: 1, padding: '3px 10px' }}>{'\u25CF'} WINNER CAM</div>
              <ImgSlot label="PHOTO" w={170} h={120} color={PAL.cyan} />
            </div>
          </div>
        </div>
      </StageBG>
      <LowerThird kicker={'THE MC \uD83D\uDD0A'} kickerColor={PAL.magenta}
        headline="&ldquo;Pete, that wasn't a performance — that was a cry for help. Kazoo takes the pot. Goodnight!&rdquo;"
        action={<BevelBtn color={PAL.orange} fg={PAL.white}>REMATCH »</BevelBtn>} />
    </BC>
  );
}

// ═══ PHONE SECOND-SCREEN (390×760) ═══════════════════════════════
const BPW = 390, BPH = 760;
function BCPhone({ children, tag = 'ON THE LIST', tagColor = PAL.cyan, blink = false }) {
  return (
    <div style={{ width: BPW, height: BPH, background: PAL.purpleDp, fontFamily: FONT.body, color: PAL.white,
      display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ background: PAL.ink, color: PAL.slime, fontFamily: FONT.mono, fontSize: 15,
        display: 'flex', justifyContent: 'space-between', padding: '3px 12px' }}>
        <span>9:41</span><span>SECOND SCREEN ▮▮▮</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 14px', background: PAL.ink,
        borderBottom: `4px solid ${PAL.ink}` }}>
        <span className={blink ? 'md-blink' : ''} style={{ background: tagColor, color: PAL.white, fontFamily: FONT.display,
          fontSize: 13, padding: '3px 10px', letterSpacing: 1 }}>{'\u25CF'} {tag}</span>
        <Logo scale={0.5} />
      </div>
      <StageBG>{children}</StageBG>
    </div>
  );
}

// 6 · phone join
function BcPhoneJoin() {
  return (
    <BCPhone tag="GUEST LIST" tagColor={PAL.cyan}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 14, padding: 16, zIndex: 2 }}>
        <div style={{ textAlign: 'center', fontFamily: FONT.display, fontSize: 26, letterSpacing: 1, color: PAL.yellow,
          textShadow: `2px 2px 0 ${PAL.ink}` }}>GET ON THE BILL</div>
        <StageCard title="ROOM CODE" titleBg={PAL.purple} titleFg={PAL.white}>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 6 }}>
            {['P', 'B', '4', 'K', '9'].map((c, i) => (
              <span key={i} style={{ ...bevelPanel(PAL.cream, { shadow: 0 }), width: 40, height: 52, display: 'flex',
                alignItems: 'center', justifyContent: 'center', fontFamily: FONT.display, fontSize: 34, color: PAL.purpleDp }}>{c}</span>
            ))}
            <span className="md-blink" style={{ ...bevelPanel(PAL.white, { shadow: 0 }), width: 40, height: 52, display: 'flex',
              alignItems: 'center', justifyContent: 'center', fontFamily: FONT.display, fontSize: 34, color: PAL.orange }}>_</span>
          </div>
        </StageCard>
        <StageCard title="CONNECT WALLET" titleBg={PAL.cyanDk} titleFg={PAL.white}>
          <BevelBtn color={PAL.orange} fg={PAL.white} big style={{ width: '100%', justifyContent: 'center' }}>★ CONNECT PHANTOM</BevelBtn>
          <div style={{ fontFamily: FONT.mono, fontSize: 16, color: PAL.purpleDp, textAlign: 'center', marginTop: 8 }}>7Bx9…f3Q · 0.42 SOL</div>
        </StageCard>
        <div style={{ marginTop: 'auto' }}>
          <MCWave compact label="THE MC · PRE-GAME" quote="Fresh meat. Try not to flatline on the first note, rookie." color={PAL.cyan} />
        </div>
      </div>
      <LowerThird kicker="ON DECK" kickerColor={PAL.yellow} kickerFg={PAL.ink}
        headline="Connect, punch the code, you're in."
        action={<BevelBtn color={PAL.slime}>JOIN »</BevelBtn>} />
    </BCPhone>
  );
}

// 7 · phone on air (your turn)
function BcPhoneTurn() {
  return (
    <BCPhone tag="ON AIR" tagColor={PAL.red} blink>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 16, padding: 18,
        alignItems: 'center', justifyContent: 'center', textAlign: 'center', zIndex: 2 }}>
        <div style={{ fontFamily: FONT.display, fontSize: 46, color: PAL.white, letterSpacing: 1, lineHeight: 0.95,
          textShadow: `3px 3px 0 ${PAL.ink}`, transform: 'rotate(-2deg)' }}>YOU'RE<br/>ON AIR!</div>
        <Splat color={PAL.red} size={120} spin>
          <span className="md-blink" style={{ fontFamily: FONT.display, fontSize: 26, color: PAL.white,
            WebkitTextStroke: `1.5px ${PAL.ink}` }}>{'\u25CF'} REC</span>
        </Splat>
        <ScoreBug a={{ name: 'YOU', score: 88, color: PAL.slime }} b={{ name: 'THEM', score: '—', color: PAL.magenta, fg: PAL.white }} />
        <div style={{ ...bevelPanel(PAL.yellow), padding: 12, width: '100%', color: PAL.ink }}>
          <div style={{ fontFamily: FONT.mono, fontSize: 18 }}>Sing into the laptop mic — the host runs the board.</div>
        </div>
      </div>
      <LowerThird kicker={'\u266A LIVE'} kickerColor={PAL.red} kickerFg={PAL.white}
        headline="FIREWORK — Katy Perry" />
    </BCPhone>
  );
}

// 8 · phone result (won)
function BcPhoneResult() {
  return (
    <BCPhone tag="FINAL" tagColor={PAL.slime}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 14, padding: 18,
        alignItems: 'center', textAlign: 'center', zIndex: 2 }}>
        <div style={{ fontFamily: FONT.display, fontSize: 52, color: PAL.slime, letterSpacing: 1, lineHeight: 0.95,
          textShadow: `3px 3px 0 ${PAL.ink}`, transform: 'rotate(-2deg)', marginTop: 6 }}>YOU<br/>WON!</div>
        <ScoreBug big a={{ name: 'YOU', score: 87, color: PAL.slime }} b={{ name: 'KAZOO', score: 71, color: PAL.magenta, fg: PAL.white }} />
        <div style={{ ...bevelPanel(PAL.white), padding: '12px 14px', width: '100%', color: PAL.ink }}>
          <div style={{ fontFamily: FONT.display, fontSize: 30, color: PAL.slimeDk }}>+0.0198 SOL</div>
          <div style={{ fontFamily: FONT.mono, fontSize: 16, color: PAL.purpleDp }}>landing in your wallet · view tx »</div>
        </div>
        <div style={{ width: '100%' }}>
          <MCWave compact quote="Clean pipes, kid. Kazoo never stood a chance." />
        </div>
      </div>
      <LowerThird kicker="REMATCH?" kickerColor={PAL.yellow} kickerFg={PAL.ink}
        headline="Run it back for double?"
        action={<BevelBtn color={PAL.slime}>GO »</BevelBtn>} />
    </BCPhone>
  );
}

Object.assign(window, {
  BcLobby, BcWaiting, BcSinging, BcScoring, BcResults,
  BcPhoneJoin, BcPhoneTurn, BcPhoneResult,
  BC_W: BW, BC_H: BH, BCP_W: BPW, BCP_H: BPH,
});
