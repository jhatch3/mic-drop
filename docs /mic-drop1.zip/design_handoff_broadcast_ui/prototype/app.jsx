// app.jsx — composes the design canvas around the BROADCAST direction.

function Swatch({ name, hex }) {
  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ width: 60, height: 46, background: hex, border: `3px solid ${PAL.ink}`, boxShadow: `3px 3px 0 ${PAL.ink}` }} />
      <div style={{ fontFamily: FONT.display, fontSize: 12, marginTop: 6, letterSpacing: 0.5 }}>{name}</div>
    </div>
  );
}

function KitTile() {
  return (
    <div style={{ width: 1024, height: 680, background: PAL.purpleDp, fontFamily: FONT.body, color: PAL.white,
      overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <OnAirBar tag="ON AIR" tagColor={PAL.red} right="MIC DROP TV · BROADCAST KIT" />
      <div style={{ flex: 1, padding: 18, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, alignContent: 'start' }}>
        <div style={{ ...bevelPanel(PAL.white), padding: 14, color: PAL.ink }}>
          <div style={{ fontFamily: FONT.display, fontSize: 16, letterSpacing: 1, color: PAL.purple, marginBottom: 10 }}>PALETTE</div>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            <Swatch name="SLIME" hex={PAL.slime} /><Swatch name="ORANGE" hex={PAL.orange} />
            <Swatch name="PURPLE" hex={PAL.purple} /><Swatch name="MAGENTA" hex={PAL.magenta} />
            <Swatch name="CYAN" hex={PAL.cyan} /><Swatch name="YELLOW" hex={PAL.yellow} />
            <Swatch name="INK" hex={PAL.ink} />
          </div>
        </div>
        <div style={{ ...bevelPanel(PAL.white), padding: 14, color: PAL.ink }}>
          <div style={{ fontFamily: FONT.display, fontSize: 16, letterSpacing: 1, color: PAL.purple, marginBottom: 6 }}>TYPE</div>
          <div style={{ fontFamily: FONT.display, fontSize: 34, lineHeight: 0.95 }}>ANTON — LOUD DISPLAY</div>
          <div style={{ fontFamily: FONT.logo, fontSize: 20, color: PAL.purple }}>BUNGEE LOGO</div>
          <div style={{ fontFamily: FONT.body, fontWeight: 800, fontSize: 17 }}>Archivo — body copy &amp; captions.</div>
          <div style={{ fontFamily: FONT.mono, fontSize: 19, color: PAL.purpleDp }}>VT323 mono — codes &amp; 0x txns</div>
        </div>

        <div style={{ gridColumn: '1 / -1', display: 'flex', gap: 14, alignItems: 'flex-start', flexWrap: 'wrap' }}>
          <div style={{ flex: '1 1 280px' }}>
            <div style={{ fontFamily: FONT.display, fontSize: 14, letterSpacing: 1, color: PAL.slime, marginBottom: 8 }}>SCORE BUG &amp; NAMEPLATE</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'flex-start' }}>
              <ScoreBug a={{ name: 'KAZOO', score: 87, color: PAL.slime }} b={{ name: 'PETE', score: 71, color: PAL.magenta, fg: PAL.white }} />
              <Nameplate kicker="NOW SINGING" name="KAZOO_KING" color={PAL.slime} />
            </div>
          </div>
          <div style={{ flex: '1 1 320px' }}>
            <div style={{ fontFamily: FONT.display, fontSize: 14, letterSpacing: 1, color: PAL.slime, marginBottom: 8 }}>MC VOICE (replaces the mascot)</div>
            <MCWave compact quote="That wasn't singing — that was a hostage situation." />
          </div>
          <div style={{ flex: '0 0 auto', display: 'flex', gap: 10, alignItems: 'flex-end', paddingTop: 24 }}>
            <BevelBtn color={PAL.slime}>GO LIVE »</BevelBtn>
            <BevelBtn color={PAL.orange} fg={PAL.white} blink>REC</BevelBtn>
            <Splat color={PAL.yellow} size={64}><span style={{ fontFamily: FONT.display, fontSize: 13, color: PAL.ink }}>+SOL</span></Splat>
          </div>
        </div>

        <div style={{ gridColumn: '1 / -1' }}>
          <div style={{ fontFamily: FONT.display, fontSize: 14, letterSpacing: 1, color: PAL.slime, marginBottom: 8 }}>THE SIGNATURE — LOWER-THIRD</div>
          <div style={{ border: `4px solid ${PAL.ink}`, boxShadow: `5px 5px 0 ${PAL.ink}` }}>
            <LowerThird kicker={'THE MC \uD83D\uDD0A'} kickerColor={PAL.magenta}
              headline="Kicker chip · headline caption · optional action — the through-line of every screen."
              action={<BevelBtn color={PAL.orange} fg={PAL.white}>REMATCH »</BevelBtn>} />
          </div>
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <DesignCanvas>
      <DCSection id="kit" title="Broadcast Kit" subtitle="The on-air system — bars, lower-thirds, score bugs, nameplates, MC voice">
        <DCArtboard id="tile" label="Broadcast kit" width={1024} height={680}><KitTile /></DCArtboard>
        <DCPostIt top={-12} left={1100} width={264} rotate={-3}>
          <b>Direction:</b> MIC DROP as a live TV broadcast. ON-AIR bar up top, purple stage in the
          middle, and the signature <b>lower-third banner</b> running every caption. The MC is now a
          <b> voice</b> (waveform + lower-third), no mascot.
        </DCPostIt>
      </DCSection>

      <DCSection id="bhost" title="Host · Laptop" subtitle="The broadcast desk — full show flow">
        <DCArtboard id="lobby"   label="1 · Pre-Show / Create Battle" width={BC_W} height={BC_H}><BcLobby /></DCArtboard>
        <DCArtboard id="waiting" label="2 · Green Room (call-in)"      width={BC_W} height={BC_H}><BcWaiting /></DCArtboard>
        <DCArtboard id="singing" label="3 · On Air / Singing"         width={BC_W} height={BC_H}><BcSinging /></DCArtboard>
        <DCArtboard id="scoring" label="4 · Instant Replay / Scoring" width={BC_W} height={BC_H}><BcScoring /></DCArtboard>
        <DCArtboard id="results" label="5 · Final / Results"          width={BC_W} height={BC_H}><BcResults /></DCArtboard>
      </DCSection>

      <DCSection id="bphone" title="Player · Phone" subtitle="The second screen — couch-side, on-air styling">
        <DCArtboard id="join"   label="6 · Join / Guest List" width={BCP_W} height={BCP_H}><BcPhoneJoin /></DCArtboard>
        <DCArtboard id="turn"   label="7 · You're On Air"      width={BCP_W} height={BCP_H}><BcPhoneTurn /></DCArtboard>
        <DCArtboard id="presult" label="8 · Result (won)"      width={BCP_W} height={BCP_H}><BcPhoneResult /></DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
