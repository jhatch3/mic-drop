# Handoff: MIC DROP — "Broadcast" UI Redesign

## Overview
A complete visual overhaul of the **MIC DROP / Pitch Battle** frontend (PvP karaoke staking game on Solana). The new direction is an **early-2000s live-TV broadcast** aesthetic: an `ON-AIR` bar across the top, a purple "stage" in the middle, and a signature **lower-third banner** that carries every caption/CTA along the bottom. Loud condensed type, saturated color blocks, hard ink outlines, offset drop-shadows, blink/marquee/equalizer motion.

The **AI MC host is represented as a *voice*** — a magenta-tagged commentary **waveform** + the lower-third caption — **not** a character/mascot. (An earlier mascot concept was explicitly removed; do **not** reintroduce any character art.)

This is an **original** brand inspired by the *era* of late-90s/early-2000s kids' web — it is **not** Nickelodeon and must not use Nickelodeon logos, marks, or assets.

## About the Design Files
The files in `prototype/` are **design references created in HTML/React-via-Babel** — they show intended look, layout, copy, and motion. They are **not** production code to copy verbatim. Your task is to **recreate these designs inside the existing `mic-drop/frontend` app** (React 18 + Vite + TypeScript), reusing its real data/state/wallet/socket logic and replacing only the presentation layer.

How to view the prototype: open `prototype/MIC DROP Redesign.html` in a browser (it loads React + Babel from CDN). It renders a pan/zoom canvas of all screens. Source of truth for tokens & components is `prototype/ds.jsx`; all screens are in `prototype/broadcast.jsx`; the canvas layout is `prototype/app.jsx` (canvas wrapper `design-canvas.jsx` is irrelevant to the app — ignore it when implementing).

## Fidelity
**High-fidelity (hifi).** Exact colors, fonts, sizes, and copy are specified below and in `ds.jsx`. Recreate pixel-for-pixel using the frontend's own component patterns. Where the prototype uses fixed pixel frames (1024×720 laptop, 390×760 phone), implement as **responsive/fluid** layouts that keep the same proportions and hierarchy — the host views are laptop/desktop, the player views are mobile.

---

## Target Codebase Map

The redesign touches the **frontend only**. Do not change game logic, escrow, socket events, or backend calls — only swap the rendered UI. Key files:

| Design screen(s) | Implement in | Notes |
|---|---|---|
| Host: Pre-Show, Green Room, On Air, Replay, Final | `frontend/src/game/Host.tsx` | Replace the `styles` object + JSX for each `phase` (`lobby`→Pre-Show, `waiting`→Green Room, `gaming`→On Air, `scoring`→Replay, `finished`→Final). Keep all hooks, socket handlers, Anchor calls, `addLog`, refs. |
| Player phone: Join, On Air, Result | `frontend/src/game/Player.tsx` | Replace `styles` + JSX per state (`!joined`→Join, `p1/p2_singing`→On Air, `gameOver`→Result, `waiting`→Lobby). Keep socket logic. |
| On-Air singing gameplay (pitch meter, lyrics caption, score) | `frontend/src/game/Karaoke.tsx` | Re-skin the top bar, pitch-graph container, score panel, tuner, and lyric caption. Keep `detectPitch`, scoring, canvas drawing logic; restyle `drawGraph` colors (see Pitch Meter below). |
| Local hot-seat (Setup, Handoff, Results) | `frontend/src/game/LocalGame.tsx` | Not mocked in this round but should adopt the same kit; apply broadcast styling consistently. Ask designer for mocks if needed. |
| Solana test UI | `frontend/src/App.tsx` | Optional: lightly adopt tokens; low priority (dev tool). |
| Shared primitives | NEW: `frontend/src/ui/` | Create the design-system components below once and reuse across all screens. |

### Recommended new files
```
frontend/src/ui/theme.ts          // design tokens (PAL, FONT, shadow helpers)
frontend/src/ui/Broadcast.tsx      // OnAirBar, StageBG, LowerThird, ScoreBug, Nameplate, MCWave
frontend/src/ui/Kit.tsx            // BevelBtn, GoPill, Splat, Panel, Logo, Ticker, ImgSlot, Chevrons
frontend/src/ui/fonts.css          // @import Google Fonts (or self-host)
```
Port the implementations directly from `prototype/ds.jsx` and `prototype/broadcast.jsx` (they are plain React + inline styles; convert to TS + your styling approach — inline styles are fine, or migrate to CSS modules/your choice).

---

## Design Tokens

### Color palette (exact hex — from `ds.jsx` `PAL`)
```
ink       #0B0B0B   // outlines, bars, text on light
slime     #B6FF00   // primary accent / "win" / CTAs
slimeDk   #79B000   // slime text on light, win scores
orange    #FF6B00   // secondary CTA / "waiting"
orangeDk  #B84A00
purple    #8E2DE2   // brand, headers
purpleDp  #5A1799   // stage base, body text on light, deep bg
magenta   #FF1C8E   // MC voice, "loser", LIVE kicker
cyan      #13D7E8   // info / QR / standby
cyanDk    #0792A0
yellow    #FFD400   // "up next", highlights, payout splat
red       #FF2E2E   // ON AIR / REC
cream     #FFFDEB   // input fields on white panels
paper     #F2ECD6   // light page bg (used sparingly)
white     #FFFFFF   // panel bg
```

### Typography (Google Fonts)
```
display : 'Anton'        // loud condensed headlines, scores, labels (UPPERCASE)
logo    : 'Bungee'       // the MIC DROP wordmark only
body    : 'Archivo'      // weights 400–900; UI copy & captions (use 700–800 for emphasis)
mono    : 'VT323'        // room codes, wallet addrs, tx hashes, timers, "TV" status text
```
Load: `@import url('https://fonts.googleapis.com/css2?family=Anton&family=Bungee&family=Archivo:wght@400;500;600;700;800;900&family=VT323&display=swap');`
Minimum sizes: laptop body ≥16px, mono ≥15px; mobile hit targets ≥44px.

### Shape & depth (the "chunky" look)
- **Outlines:** `3–4px solid #0B0B0B` on every panel, button, chip.
- **Hard offset shadow (no blur):** `Npx Npx 0 #0B0B0B`, N = 4–8 (bigger = more prominent). Helper in `ds.jsx`: `bevelPanel(bg, {shadow, bw})`.
- **Beveled button face:** `inset 3px 3px 0 rgba(255,255,255,.5), inset -3px -3px 0 rgba(0,0,0,.28), 4px 4px 0 #0B0B0B`. Helper: `bevelFace(bg)`.
- **Border radius:** `0` everywhere (sharp edges) — the only round things are circles/`Splat` blobs and pill chips (`border-radius:999px`).
- **Splat blob** (organic shape): `border-radius: 49% 51% 47% 53% / 53% 47% 53% 47%` with a 3px ink border.

### Motion (keyframes — see prototype HTML `<style>`)
```
mdBlink   : opacity 1 → 0.18, 0.9s steps(1) infinite   // .md-blink (REC dot, cursors, "…")
mdMarquee : translateX(0 → -50%) linear                 // ticker scroll
mdSpin    : rotate(0 → 360deg) 14s linear               // splat idle spin
mdEq      : scaleY(0.45 → 1 → 0.45) 0.7s ease-in-out    // .md-eq equalizer bars (transform-origin:bottom)
```
Button press feedback (`.md-press`): translate(-1px,-1px) on hover; translate(3px,3px) + drop the offset shadow on `:active` (simulates pressing the bevel down).

---

## Core Components (build once, in `frontend/src/ui/`)

> Full reference implementations are in `prototype/ds.jsx` (kit) and the screen usages in `prototype/broadcast.jsx`. Specs below summarize props & appearance.

1. **`Logo({ scale })`** — wordmark. "MIC" in white with `WebkitTextStroke 2.5px ink` + ink text-shadow, rotated −8°; "DROP" in yellow on a purple box with ink border, rotated +2°. Font: Bungee.

2. **`OnAirBar({ tag, tagColor, right, blink })`** — full-width top bar, `bg:#0B0B0B`, `borderBottom:4px ink`. Left: a blinking status chip (`●` + tag, e.g. "ON AIR"/red, "STANDBY"/cyan, "REPLAY"/yellow, "FINAL"/slime) — `blink` toggles the `.md-blink` class. Then `<Logo scale=0.58/>`. Right: `mono` text in slime (e.g. `MIC DROP TV · LIVE FROM DEVNET`).

3. **`StageBG({ children })`** — the middle stage. `flex:1`, radial wash `radial-gradient(circle at 50% 24%, #8E2DE2 0%, #5A1799 72%)`, plus faint vertical "spotlight" stripes overlay: `repeating-linear-gradient(90deg, transparent 0 74px, rgba(255,255,255,.05) 74px 76px)`. Children render above (`z-index:2`).

4. **`LowerThird({ kicker, kickerColor, kickerFg, headline, bodyColor, action })`** — THE signature element. A horizontal bar, `borderTop:4px ink`, three segments separated by `4px ink` borders:
   - **Kicker chip** (left): `kickerColor` bg, Anton 20px, letterspacing 1, padding 14×18, nowrap (e.g. "LIVE ♪"/red, "UP NEXT"/yellow, "WAITING"/orange, "THE MC 🔊"/magenta, "FINAL"/slime).
   - **Headline** (center, flex:1): `bodyColor` (default slime) bg, ink text, Archivo 800 21px, line-height 1.12.
   - **Action** (optional right): same bodyColor bg, holds a `BevelBtn`.

5. **`ScoreBug({ a, b, big })`** — segmented VS bug. `border:4px ink`, `shadow 6px`. Three cells: `a` (name + bold score), ink "VS" cell, `b` (bold score + name). Each cell takes `{name, score, color, fg}`. Anton; `big` → 34px else 26px. Player A typically slime, B magenta(+white fg).

6. **`Nameplate({ kicker, name, sub, color })`** — competitor ID lower-third. Stacked: ink strip with `kicker` (Anton 14, letterspacing 2, colored text) above a `color` strip with `name` (Anton 32) + optional `sub` (mono 16, e.g. W-L record). `border 4px ink`, `shadow 5px`.

7. **`MCWave({ quote, label, bars, color, compact })`** — the MC's "voice" (replaces mascot). A white `bevelPanel`. Top: magenta chip `🔊 {label}` (default `THE MC · ON THE CALL`). Middle: a row of `bars` (default 30) equalizer rectangles, each `1.5px ink` border, every 3rd bar magenta else `color` (slime), animated via `.md-eq` with staggered `animation-delay`. Bottom: `quote` in Archivo 800 (21px, or 17px when `compact`). Heights are deterministic from a sine function — see `ds.jsx`.

8. **`BevelBtn({ color, fg, big, blink, children })`** — chunky beveled button (uses `bevelFace`). Anton, uppercase, letterspacing .5; `big` → 26px/12×28 padding else 18px/8×18. `.md-press` interaction. `blink` adds attention pulse. Use `»` (Chevrons) for forward actions.

9. **`Splat({ color, size, spin, children })`** — organic blob (see border-radius above). Used for the **payout bug** (yellow, "+0.0198 SOL / PAID ✓") and the phone REC indicator (red, spinning).

10. **`Panel` / `StageCard`** — bordered card with optional title strip (ink bg, colored Anton title). `StageCard` (in `broadcast.jsx`) is the white-on-stage variant with `shadow 7`. **`ImgSlot({ label, w, h, color })`** — dashed striped placeholder for user photos (e.g. WINNER CAM).

11. **`Ticker({ items, bg, fg, label, speed })`** — marquee bar (label chip + scrolling mono text). Optional; used decoratively.

---

## Screens / Views

### HOST · LAPTOP (`Host.tsx`) — frame 1024×720, implement fluid/desktop

**1 · Pre-Show / Create Battle** — `phase === 'lobby'`
- Purpose: host picks song + wager and goes live.
- Layout: `OnAirBar` (tag "STANDBY"/cyan, not blinking, right "MIC DROP TV · GREEN ROOM") → `StageBG` (centered column) → `LowerThird`.
- Stage: kicker "TONIGHT'S MATCHUP" (Anton 26, yellow, letterspacing 4); a row of two `Nameplate`s with a big "VS" between (CHAMPION/slime "KAZOO_KING 15-3" vs CHALLENGER/magenta "OPEN SEAT"); below, a `StageCard` titled "SET THE BILL" containing a TRACK list (song rows: ▶/♪ icon, title in Anton, artist in mono, difficulty as ★) and two fields WAGER (`0.01 SOL`) + WINNER TAKES (`0.0198 SOL`) in cream inset boxes.
- Lower-third: kicker "UP NEXT"/yellow(ink fg), headline "Lock the track and the wager — then put it on air.", action `BevelBtn slime` "GO LIVE »".
- Wire-up: song list from `/api/songs` (existing `songs` state); wager → existing `stakeSOL` input; "GO LIVE" → existing `createRoom()`. Keep the "Play local — no wallet" path (link to `/local`) somewhere (e.g. a small chip in the OnAirBar or a secondary lower-third action).

**2 · Green Room / Call-In** — `phase === 'waiting'`
- Purpose: show room code + QR, wait for P2, then start.
- Stage: kicker "CALL IN TO COMPETE" (Anton 30 yellow, ink shadow); a row of two `StageCard`s — "ROOM CODE" (purple title) with the code in Anton 84 letterspacing 8 + `micdrop.fun/play` in mono, and "OR SCAN" (cyanDk title) with the QR. Below: a `StageCard` "ROSTER  1 / 2 CHECKED IN" with one slime check-in row (`✓ kazoo_king  7Bx9…f3Q   P1 · HOST`, mono, nowrap) and one dashed "● standing by for challenger…" row (orange blinking dot).
- Lower-third: kicker "WAITING"/orange, headline "Challenger hasn't checked in yet. We'll stall — the MC's got material.", action greyed `BevelBtn slime` "START »" (enabled when `room.players.length === 2`).
- Wire-up: `room.code`, `joinUrl` (existing `react-qr-code` QRCode), `room.players`; "START" → existing `startGame()`. Replace the placeholder QR in the prototype with the real `<QRCode/>`.

**3 · On Air / Singing** — `phase === 'gaming'` (and see `Karaoke.tsx`)
- Purpose: live performance with real-time pitch + score.
- `OnAirBar` tag "ON AIR"/red **blinking**, right `ROUND 1 · LIVE · 02:14` (timer).
- Stage: top row = `Nameplate` "NOW SINGING / KAZOO_KING" (slime) on the left, `ScoreBug` on the right (current singer's live score vs `—`). Center = **Pitch Meter** (see below) on the left, and on the right a column: LIVE SCORE card (slime `bevelPanel`, Anton 64 score + "x / y hit" mono) and two note chips YOU (`A4`, yellow) / TGT (`A#4`, magenta).
- Lower-third = the **karaoke caption**: kicker "♪ LIVE"/red, headline = current lyric line with the active word highlighted (`background:yellow; border:2px ink; padding:0 6px`), action `BevelBtn orange` "END TURN »".
- Wire-up: this maps onto `Karaoke.tsx`. Use existing `score`, `hits`, `scored`, `liveMidi`/`targetMidi` (`noteFromMidi`), active lyric line, and the `endTurn`/`finishTurn` handler. Keep all detection logic.

**4 · Instant Replay / Scoring** — `phase === 'scoring'`
- `OnAirBar` tag "REPLAY"/yellow (not blinking), right "MIC DROP TV · JUDGES' ROOM".
- Stage (centered): "INSTANT REPLAY…" (Anton 56 white, ink shadow, blinking ellipsis); a `big` `ScoreBug` showing both final takes; a wide `MCWave` (label "THE MC · DELIBERATING", quote "Both takes are in. Let me find the words for what Pete just did to that chorus…"); a striped progress bar (orange/yellow diagonal stripes ~70%).
- Lower-third: kicker "SCORING"/magenta, headline "Reviewing every frame of both performances. Counting the SOL. Sharpening the burns."
- Wire-up: shown while awaiting `/api/match/finish`. No actions.

**5 · Final / Results** — `phase === 'finished'`
- `OnAirBar` tag "FINAL"/slime, right "MIC DROP TV · THE VERDICT".
- Stage: centered "YOUR WINNER" (Anton 26 yellow ls 4) + winner name (Anton 92 white, 5px ink shadow, rotate −1°) + a `big` `ScoreBug`. Corner bugs: top-left a yellow `Splat` "+0.0198 SOL / PAID ✓"; bottom-right a "● WINNER CAM" framed `ImgSlot` (photo placeholder, rotate +2°).
- Lower-third: kicker "THE MC 🔊"/magenta, headline = the AI roast quote (curly quotes), action `BevelBtn orange` "REMATCH »".
- Wire-up: winner from `finish.winner`/`room.winner`; scores from `finish.scores`; payout from `finish.payout_tx` (link to explorer when devnet); roast from `finish.commentary`; keep the `<audio>` MC playback (`finish.mc_audio_url`) — trigger it from a control near the lower-third (e.g. a 🔊 button on the kicker). Leaderboard (`finish.leaderboard`) can sit as a small `Panel` on the stage if desired.

### Pitch Meter (`Karaoke.tsx` → `drawGraph`)
Re-skin the existing canvas graph to broadcast colors: background `#0B0B0B`, grid lines `rgba(255,255,255,.10)`, **target line magenta `#FF1C8E` (7px)**, **singer line yellow `#FFD400` (5px)**, current-point dot slime `#B6FF00` with 3px ink stroke. Wrap the canvas in a `4px ink` border + `6px` offset shadow. Legend chips top-left: "● TARGET" (magenta) / "● YOU" (yellow) as Anton chips with ink borders. Keep all detection/scoring math unchanged.

### PLAYER · PHONE (`Player.tsx`) — frame 390×760, implement mobile-fluid
Phone shell = ink status strip (`9:41` / `SECOND SCREEN ▮▮▮` in mono slime) → compact ink bar with a status chip + small `Logo scale=0.5` → `StageBG` → compact `LowerThird`.

**6 · Join / Guest List** — `!joined`
- Chip "GUEST LIST"/cyan. Stage: "GET ON THE BILL" (Anton 26 yellow); `StageCard` "ROOM CODE" with per-character cream boxes (Anton 34) + a blinking orange `_` cursor; `StageCard` "CONNECT WALLET" with a full-width `BevelBtn orange` "★ CONNECT PHANTOM" + mono `7Bx9…f3Q · 0.42 SOL`; a `compact MCWave` (label "THE MC · PRE-GAME", cyan, quote "Fresh meat. Try not to flatline on the first note, rookie.").
- Lower-third: kicker "ON DECK"/yellow, headline "Connect, punch the code, you're in.", action `BevelBtn slime` "JOIN »".
- Wire-up: code input (`code` state, 6 chars), `WalletMultiButton` (style it to match, or wrap), `joinRoom()`.

**7 · You're On Air** — `room.state` p1/p2 singing & `myTurn`
- Chip "ON AIR"/red blinking. Stage (centered): "YOU'RE ON AIR!" (Anton 46 white, rotate −2°); red spinning `Splat` (size 120) with blinking "● REC"; a `ScoreBug` (YOU vs THEM); a yellow `bevelPanel` "Sing into the laptop mic — the host runs the board."
- Lower-third: kicker "♪ LIVE"/red, headline "FIREWORK — Katy Perry" (current song).
- Opponent's turn variant: show "OPPONENT'S TURN" state instead (reuse existing `myTurn` logic).

**8 · Result (won)** — `gameOver` + `finish`
- Chip "FINAL"/slime. Stage: "YOU WON!" (Anton 52 slime, rotate −2°) [or "YOU LOST" magenta / "TIE" yellow per outcome]; a `big` `ScoreBug`; a white `bevelPanel` "+0.0198 SOL / landing in your wallet · view tx »"; a `compact MCWave` with the roast.
- Lower-third: kicker "REMATCH?"/yellow, headline "Run it back for double?", action `BevelBtn slime` "GO »".
- Wire-up: outcome from `room.winner` vs `wallet.publicKey`; `finish.payout_tx`, `finish.commentary`.

---

## Interactions & Behavior
- **Blink**: REC dots, input cursors, "standing by…" dot, scoring "…" → `.md-blink` (0.9s steps).
- **Equalizer**: `MCWave` bars animate continuously (`.md-eq`, staggered delays) to imply the MC "talking". Pause when no audio if you want fidelity to playback state.
- **Button press**: `.md-press` hover lift + active "press-in" (shadow collapses).
- **Splat idle spin**: optional 14s rotate on decorative splats; the phone REC splat spins.
- **Marquee/ticker**: optional; if used, `mdMarquee` infinite.
- **Navigation/flows are unchanged** — they already exist in the components (phase/state machines, socket events `room:created/updated`, `game:started`, `turn:start`, `game:over`, `match:finished`). Only the rendered markup/styles change.
- Preserve all **loading/error/empty** states (e.g. "Loading…" song list, error strings, log panel) — restyle them into small mono captions or lower-thirds rather than removing them.

## State Management
No new app state is required — reuse what each component already owns (`phase`, `room`, `finish`, `currentTurn`, wallet/connection, socket). The redesign is presentational. If you extract UI components, pass the existing values as props. The dev **log panel** in `Host.tsx` can be kept (collapse it into a small monospace "DIRECTOR'S LOG" drawer) — useful during the hackathon.

## Assets
- **Fonts:** Anton, Bungee, Archivo, VT323 (Google Fonts) — see import above. Self-host if offline builds are needed.
- **QR:** use the existing `react-qr-code` dependency (already imported in `Host.tsx`).
- **Photos:** the "WINNER CAM" is an `ImgSlot` placeholder — no asset shipped. Wire to a real avatar/photo source if available, else leave the placeholder.
- **No icon library needed**; the design uses Unicode glyphs (`● » ♪ ★ ✓ 🔊 ♛`) and CSS shapes only. No mascot/character art.

## Files (in this bundle, under `prototype/`)
- `MIC DROP Redesign.html` — open this to view all screens (pan/zoom canvas).
- `ds.jsx` — **design system**: `PAL`, `FONT`, `bevelPanel`, `bevelFace`, and components `Logo, OnAirBar, StageBG, LowerThird, ScoreBug, Nameplate, MCWave, BevelBtn, GoPill, Splat, Panel, Ticker, ImgSlot, Chevrons` (+ unused legacy `SiteChrome/TabNav/LoginStrip` — ignore).
- `broadcast.jsx` — **all screen layouts** (`BcLobby, BcWaiting, BcSinging, BcScoring, BcResults, BcPhoneJoin, BcPhoneTurn, BcPhoneResult`) plus `StageCard`, `SongLine`, `PitchMeter`, `QRBlock`. This is your primary reference for composition.
- `app.jsx` — canvas composition only (which screen goes where). Not part of the app.
- `design-canvas.jsx` — prototype canvas harness; **ignore** for implementation.

## Implementation order (suggested)
1. `theme.ts` tokens + fonts + `Kit.tsx` primitives (BevelBtn, Logo, Splat, Panel).
2. `Broadcast.tsx` (OnAirBar, StageBG, LowerThird, ScoreBug, Nameplate, MCWave).
3. `Host.tsx` phases 1→5 (biggest surface).
4. `Karaoke.tsx` reskin + `drawGraph` recolor.
5. `Player.tsx` phone states.
6. `LocalGame.tsx` + `App.tsx` (apply kit for consistency).
7. QA: responsive behavior, motion, contrast, ≥44px mobile targets.
